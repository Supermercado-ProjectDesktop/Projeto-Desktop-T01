/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuration;

/**
 *
 * @author JOAO
 */
public abstract class Configurations {
    public String TYPE;
    public String HOST;
    public String USER;
    public String PASS;
    public String PORT;
    public String BASE;
    public String DRIV;
}
